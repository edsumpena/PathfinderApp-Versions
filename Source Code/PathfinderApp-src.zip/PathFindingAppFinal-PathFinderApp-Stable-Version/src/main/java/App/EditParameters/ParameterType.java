package App.EditParameters;

public enum ParameterType {
    INT,
    BOOLEAN,
    LONG,
    DOUBLE,
    STRING,
    CHAR,
    FLOAT
}
